package com.kasp.rbw;

public enum EmbedType {

    ERROR,
    SUCCESS,
    DEFAULT;
}
