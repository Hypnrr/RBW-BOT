package com.kasp.rbw.commands.party;

import com.andrei1058.bedwars.api.arena.IArena;
import com.kasp.rbw.CommandSubsystem;
import com.kasp.rbw.EmbedType;
import com.kasp.rbw.RBW;
import com.kasp.rbw.commands.Command;
import com.kasp.rbw.instance.Embed;
import com.kasp.rbw.instance.GameMap;
import com.kasp.rbw.instance.Party;
import com.kasp.rbw.instance.Player;
import com.kasp.rbw.instance.cache.MapCache;
import com.kasp.rbw.instance.cache.PartyCache;
import com.kasp.rbw.instance.cache.PlayerCache;
import com.kasp.rbw.messages.Msg;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.TextChannel;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PartyQueueCmd extends Command {

    public PartyQueueCmd(String command, String usage, String[] aliases, String description, CommandSubsystem subsystem) {
        super(command, usage, aliases, description, subsystem);
    }

    @Override
    public void execute(String[] args, Guild guild, Member member, TextChannel channel, Message message) {
        if (!Player.isRegistered(member.getId())) {
            Embed reply = new Embed(EmbedType.ERROR, "Not Registered", Msg.getMsg("not-registered"), 1);
            message.replyEmbeds(reply.build()).queue();
            return;
        }

        Player player = PlayerCache.getPlayer(member.getId());
        Party party = PartyCache.getParty(player);

        if (party == null) {
            Embed reply = new Embed(EmbedType.ERROR, "Not In Party", Msg.getMsg("not-in-party"), 1);
            message.replyEmbeds(reply.build()).queue();
            return;
        }

        if (party.getLeader() != player) {
            Embed reply = new Embed(EmbedType.ERROR, "Not Party Leader", Msg.getMsg("not-party-leader"), 1);
            message.replyEmbeds(reply.build()).queue();
            return;
        }

        // Check if party has valid number of players (must be even for teams)
        int partySize = party.getMembers().size();
        if (partySize < 2 || partySize % 2 != 0) {
            Embed reply = new Embed(EmbedType.ERROR, "Invalid Party Size",
                "Your party must have an even number of players (2, 4, 6, 8, etc.) to create balanced teams. Current size: `" + partySize + "`", 1);
            message.replyEmbeds(reply.build()).queue();
            return;
        }

        if (args.length < 2) {
            Embed reply = new Embed(EmbedType.ERROR, "Wrong Usage", Msg.getMsg("wrong-usage").replace("%usage%", getUsage()), 1);
            message.replyEmbeds(reply.build()).queue();
            return;
        }

        String mapName = args[1];
        GameMap gameMap = MapCache.getMap(mapName);

        if (gameMap == null) {
            Embed reply = new Embed(EmbedType.ERROR, "Invalid Map", "Map `" + mapName + "` not found. Use `=maps` to see available maps.", 1);
            message.replyEmbeds(reply.build()).queue();
            return;
        }

        // Check if map is available (not currently being used)
        if (!gameMap.getArenaState().equals(com.andrei1058.bedwars.api.arena.GameState.waiting)) {
            Embed reply = new Embed(EmbedType.ERROR, "Map Unavailable",
                Msg.getMsg("map-unavailable") + ". Map: `" + mapName + "`", 1);
            message.replyEmbeds(reply.build()).queue();
            return;
        }

        // Check if all party members are online
        for (Player p : party.getMembers()) {
            if (!p.isOnline()) {
                Embed reply = new Embed(EmbedType.ERROR, "Player Offline",
                    Msg.getMsg("player-offline") + ". `" + p.getIgn() + "` is offline.", 1);
                message.replyEmbeds(reply.build()).queue();
                return;
            }
        }

        // Start private game
        startPrivateGame(party, gameMap, channel);
    }

    private void startPrivateGame(Party party, GameMap gameMap, TextChannel channel) {
        List<Player> players = new ArrayList<>(party.getMembers());
        Collections.shuffle(players);

        // Split into two teams
        List<Player> team1 = new ArrayList<>();
        List<Player> team2 = new ArrayList<>();

        for (int i = 0; i < players.size(); i++) {
            if (i % 2 == 0) {
                team1.add(players.get(i));
            } else {
                team2.add(players.get(i));
            }
        }

        Embed embed = new Embed(EmbedType.SUCCESS, "Private Game Starting",
            "**Map:** `" + gameMap.getName() + "`\n" +
            "**Mode:** " + (players.size()/2) + "v" + (players.size()/2) + " Private Match\n" +
            "**No stats affected** - just for fun\n" +
            "*Using 4v4v4v4 map for all game modes*", 1);

        String team1List = "";
        for (Player p : team1) {
            team1List += "• <@" + p.getID() + ">\n";
        }
        embed.addField("Team 1", team1List, true);

        String team2List = "";
        for (Player p : team2) {
            team2List += "• <@" + p.getID() + ">\n";
        }
        embed.addField("Team 2", team2List, true);

        String mentions = "";
        for (Player p : players) {
            mentions += "<@" + p.getID() + ">";
        }

        channel.sendMessage(mentions).setEmbeds(embed.build()).queue();

        // Warp players to the map
        warpPlayersToMap(team1, team2, gameMap, channel);
    }

    private void warpPlayersToMap(List<Player> team1, List<Player> team2, GameMap gameMap, TextChannel channel) {
        Bukkit.getScheduler().runTask(RBW.getInstance(), () -> {
            IArena arena = RBW.bedwarsAPI.getArenaUtil().getArenaByName(gameMap.getName());

            new BukkitRunnable() {
                int tries = 0;
                final int maxTries = 5;

                @Override
                public void run() {
                    tries++;

                    try {
                        boolean allWarped = true;

                        // Warp team 1
                        for (Player p : team1) {
                            if (!arena.getPlayers().contains(Bukkit.getPlayer(p.getIgn()))) {
                                if (!arena.addPlayer(Bukkit.getPlayer(p.getIgn()), true)) {
                                    allWarped = false;
                                } else {
                                    arena.getTeams().get(0).addPlayers(Bukkit.getPlayer(p.getIgn()));
                                }
                            }
                        }

                        // Warp team 2
                        for (Player p : team2) {
                            if (!arena.getPlayers().contains(Bukkit.getPlayer(p.getIgn()))) {
                                if (!arena.addPlayer(Bukkit.getPlayer(p.getIgn()), true)) {
                                    allWarped = false;
                                } else {
                                    arena.getTeams().get(1).addPlayers(Bukkit.getPlayer(p.getIgn()));
                                }
                            }
                        }

                        if (allWarped && arena.getPlayers().size() == team1.size() + team2.size()) {
                            Embed successEmbed = new Embed(EmbedType.SUCCESS, "Game Started",
                                "All players warped to `" + arena.getArenaName() + "`\n" +
                                "Good luck and have fun!", 1);
                            channel.sendMessageEmbeds(successEmbed.build()).queue();
                            cancel();
                            return;
                        }

                        if (tries >= maxTries) {
                            Embed errorEmbed = new Embed(EmbedType.ERROR, "Failed to Start Game", 
                                "Could not warp all players to the map after " + maxTries + " attempts. Please try again.", 1);
                            channel.sendMessageEmbeds(errorEmbed.build()).queue();
                            cancel();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Embed errorEmbed = new Embed(EmbedType.ERROR, "Error", 
                            "An error occurred while starting the private game. Please try again.", 1);
                        channel.sendMessageEmbeds(errorEmbed.build()).queue();
                        cancel();
                    }
                }
            }.runTaskTimer(RBW.getInstance(), 20L, 20L * 5); // Try every 5 seconds
        });
    }
}