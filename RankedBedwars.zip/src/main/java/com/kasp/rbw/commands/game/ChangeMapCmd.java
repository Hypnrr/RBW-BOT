package com.kasp.rbw.commands.game;

import com.kasp.rbw.CommandSubsystem;
import com.kasp.rbw.EmbedType;
import com.kasp.rbw.commands.Command;
import com.kasp.rbw.instance.Embed;
import com.kasp.rbw.instance.Game;
import com.kasp.rbw.instance.GameMap;
import com.kasp.rbw.instance.cache.GameCache;
import com.kasp.rbw.instance.cache.MapCache;
import com.kasp.rbw.messages.Msg;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.TextChannel;
import java.util.ArrayList;
import java.util.Collections;

public class ChangeMapCmd extends Command {
    public ChangeMapCmd(String command, String usage, String[] aliases, String description, CommandSubsystem subsystem) {
        super(command, usage, aliases, description, subsystem);
    }

    @Override
    public void execute(String[] args, Guild guild, Member sender, TextChannel channel, Message msg) {
        Game game = GameCache.getGame(channel.getId());
        if (game == null) {
            Embed reply = new Embed(EmbedType.ERROR, "Error", Msg.getMsg("not-game-channel"), 1);
            msg.replyEmbeds(reply.build()).queue();
            return;
        }

        // Get all available maps
        ArrayList<GameMap> maps = new ArrayList<>(MapCache.getMaps().values());
        if (maps.isEmpty()) {
            Embed reply = new Embed(EmbedType.ERROR, "No Maps", "No maps are available to select.", 1);
            msg.replyEmbeds(reply.build()).queue();
            return;
        }

        // Shuffle and pick a random map
        Collections.shuffle(maps);
        GameMap newMap = maps.get(0);
        game.setMap(newMap);

        // Warp all players to the new map
        game.warpPlayersToMap(newMap);

        Embed reply = new Embed(EmbedType.SUCCESS, "🗺️ Map Changed & Players Warped", 
            "**Map:** `" + newMap.getName() + "`\n" +
            "**Players:** Successfully warped to new map\n" +
            "**Status:** Game continues on new map", 1);
        msg.replyEmbeds(reply.build()).queue();
    }
}