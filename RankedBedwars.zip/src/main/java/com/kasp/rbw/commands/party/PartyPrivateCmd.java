package com.kasp.rbw.commands.party;

import com.kasp.rbw.CommandSubsystem;
import com.kasp.rbw.EmbedType;
import com.kasp.rbw.commands.Command;
import com.kasp.rbw.instance.Embed;
import com.kasp.rbw.instance.Party;
import com.kasp.rbw.instance.Player;
import com.kasp.rbw.instance.cache.PartyCache;
import com.kasp.rbw.instance.cache.PlayerCache;
import com.kasp.rbw.messages.Msg;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.TextChannel;

public class PartyPrivateCmd extends Command {

    public PartyPrivateCmd(String command, String usage, String[] aliases, String description, CommandSubsystem subsystem) {
        super(command, usage, aliases, description, subsystem);
    }

    @Override
    public void execute(String[] args, Guild guild, Member member, TextChannel channel, Message message) {
        if (!Player.isRegistered(member.getId())) {
            Embed reply = new Embed(EmbedType.ERROR, "Not Registered", Msg.getMsg("not-registered"), 1);
            message.replyEmbeds(reply.build()).queue();
            return;
        }

        Player player = PlayerCache.getPlayer(member.getId());
        Party party = PartyCache.getParty(player);

        if (party == null) {
            Embed reply = new Embed(EmbedType.ERROR, "Not In Party", Msg.getMsg("not-in-party"), 1);
            message.replyEmbeds(reply.build()).queue();
            return;
        }

        if (party.getLeader() != player) {
            Embed reply = new Embed(EmbedType.ERROR, "Not Party Leader", Msg.getMsg("not-party-leader"), 1);
            message.replyEmbeds(reply.build()).queue();
            return;
        }

        // Toggle private status
        boolean newPrivateStatus = !party.isPrivate();
        party.setPrivate(newPrivateStatus);

        if (newPrivateStatus) {
            // Always set max members to 8 when private
            party.setMaxMembers(8);

            Embed reply = new Embed(EmbedType.SUCCESS, "Party Private",
                Msg.getMsg("party-now-private") + " Max members set to `8`.", 1);
            message.replyEmbeds(reply.build()).queue();
        } else {
            // Reset to default max members from config
            party.resetMaxMembers();

            Embed reply = new Embed(EmbedType.SUCCESS, "Party Public",
                Msg.getMsg("party-now-public"), 1);
            message.replyEmbeds(reply.build()).queue();
        }
    }
}