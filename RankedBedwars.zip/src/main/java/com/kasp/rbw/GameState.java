package com.kasp.rbw;

public enum GameState {

    STARTING,
    PLAYING,
    SUBMITTED,
    SCORED,
    VOIDED;
}
