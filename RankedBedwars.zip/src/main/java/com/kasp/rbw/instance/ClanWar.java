package com.kasp.rbw.instance;

import java.util.List;

public class ClanWar {

    private List<Player> organisers;
    private List<Clan> clans;
    private int minClans;
    private int maxClans;
    private int winXp;
    private int winGold;
}
