package com.kasp.rbw.instance;

import com.kasp.rbw.Statistic;
import com.kasp.rbw.instance.cache.PlayerCache;
import com.kasp.rbw.instance.cache.ClanCache;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

public class Leaderboard {
    private static final Map<Statistic, CachedLeaderboard> LEADERBOARD_CACHE = new ConcurrentHashMap<>();
    private static final long CACHE_DURATION = TimeUnit.MINUTES.toMillis(5); // Cache for 5 minutes

    private static class CachedLeaderboard {
        final List<String> leaderboard;
        final long timestamp;

        CachedLeaderboard(List<String> leaderboard) {
            this.leaderboard = leaderboard;
            this.timestamp = System.currentTimeMillis();
        }

        boolean isExpired() {
            return System.currentTimeMillis() - timestamp > CACHE_DURATION;
        }
    }

    private static double getWLR(Player player) {
        double losses = player.getLosses();
        return losses > 0 ? player.getWins() / losses : player.getWins();
    }

    private static double getKDR(Player player) {
        double deaths = player.getDeaths();
        return deaths > 0 ? player.getKills() / deaths : player.getKills();
    }

    public static List<String> getLeaderboard(Statistic statistic) {
        if (statistic == null) {
            return new ArrayList<>();
        }

        // Check cache first
        CachedLeaderboard cached = LEADERBOARD_CACHE.get(statistic);
        if (cached != null && !cached.isExpired()) {
            return new ArrayList<>(cached.leaderboard);
        }

        List<String> lb = new ArrayList<>();
        Collection<Player> players = PlayerCache.getPlayers().values();
        
        if (players.isEmpty()) {
            return lb;
        }

        // Special handling for ratio statistics (WLR, KDR)
        Comparator<Player> comparator = (p1, p2) -> {
            if (statistic == Statistic.WLR) {
                double wlr1 = getWLR(p1);
                double wlr2 = getWLR(p2);
                return Double.compare(wlr2, wlr1);
            } else if (statistic == Statistic.KDR) {
                double kdr1 = getKDR(p1);
                double kdr2 = getKDR(p2);
                return Double.compare(kdr2, kdr1);
            } else {
                return Double.compare(p2.getStatistic(statistic), p1.getStatistic(statistic));
            }
        };

        // Sort players and create the leaderboard
        List<Player> sortedPlayers = players.stream()
            .filter(Objects::nonNull)
            .sorted(comparator)
            .toList();

        for (Player player : sortedPlayers) {
            double value = statistic == Statistic.WLR ? getWLR(player) :
                          statistic == Statistic.KDR ? getKDR(player) :
                          player.getStatistic(statistic);
            lb.add(player.getID() + "=" + value);
        }

        // Cache the result
        LEADERBOARD_CACHE.put(statistic, new CachedLeaderboard(lb));
        
        return lb;
    }

    private static List<Clan> cachedClanLeaderboard = null;
    private static long lastClanLeaderboardUpdate = 0;

    // Add clan leaderboard support with caching
    public static List<Clan> getClansLeaderboard() {
        // Check if cache is valid
        if (cachedClanLeaderboard != null && 
            System.currentTimeMillis() - lastClanLeaderboardUpdate < CACHE_DURATION) {
            return new ArrayList<>(cachedClanLeaderboard);
        }

        Collection<Clan> clans = ClanCache.getClans().values();
        
        if (clans.isEmpty()) {
            return new ArrayList<>();
        }

        List<Clan> sortedClans = clans.stream()
            .filter(Objects::nonNull)
            .sorted((c1, c2) -> {
                // Null-safe comparison
                int rep1 = c1 != null ? c1.getReputation() : 0;
                int rep2 = c2 != null ? c2.getReputation() : 0;
                return Integer.compare(rep2, rep1);
            })
            .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);

        // Update cache
        cachedClanLeaderboard = sortedClans;
        lastClanLeaderboardUpdate = System.currentTimeMillis();

        return new ArrayList<>(sortedClans);
    }
}
