package com.kasp.rbw;

public enum CommandSubsystem {

    SERVER,
    PLAYER,
    PARTY,
    GAME,
    UTILITIES,
    MODERATION;
}
