package com.kasp.rbw;

public enum PickingMode {

    AUTOMATIC,
    CAPTAINS;
}
